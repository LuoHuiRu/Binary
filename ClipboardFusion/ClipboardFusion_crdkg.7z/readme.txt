1.) Unpack and install         
2.) During installation process if asked for a "License Key" choose "Use Trial Version..."   
3.) Block program with your firewall solution    
4.) Use our keygen to register at Settings >> License Key
5.) Enjoy!