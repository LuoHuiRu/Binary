================================================================================
|        __________             .___.______  _______  _______ ____             |
|        \______   \_____     __| _/|__\   \/  /\   \/  /_   /_   |            |
|         |       _/\__  \   / __ | |  |\     /  \     / |   ||   |            |
|         |    |   \ / __ \_/ /_/ | |  |/     \  /     \ |   ||   |            |
|         |____|_  /(____  /\____ | |__/___/\  \/___/\  \|___||___|            |
|                \/      \/      \/          \_/      \_/          2018        |
|                                                                              |
+-[ RELEASE INFO ]-------------------------------------------------------------+
|                                                                              |
| - Name......: den4b Products Keygen                                          |
| - Date......: 2018-07-28                                                     |
| - Version...: 1.0                                                            |
| - File......: Keygen.exe                                                     |
| - MD5.......: 65a292a3237e5a854e5f24af9add7090                               |
| - SHA1......: 4649c32afab1adbde9b3dff91afa1312d005c53c                       |
|                                                                              |
+-[ TARGET INFO ]--------------------------------------------------------------+
|                                                                              |
| - Category..: Misc. Tools                                                    |
| - Protection: Custom                                                         |
| - OS........: WinALL                                                         |
| - Homepage..: http://www.den4b.com                                           |
|                                                                              |
+-[ TARGET DESCRIPTION ]-------------------------------------------------------+
|                                                                              |
| Colors Pro                                                                   |
| ==========                                                                   |
|                                                                              |
| Color picker that helps you easily select a desired color using various      |
| pallets. It is also able to pick a color from the currently displayed screen |
| content and supports a number of different color models, i.e. RGB, HSV, HLS, |
| CMYK.                                                                        |
|                                                                              |
| CPUMon Pro                                                                   |
| ==========                                                                   |
|                                                                              |
| CPUMon is a simple little gadget for monitoring CPU performance from your    |
| desktop. It displays a real-time graph of CPU performance as well as current |
| usage indicator. Features include user defined colors, transparency,         |
| alpha-blending, adjustable update rates, layout presets, window locking,     |
| constantly updated CPU speed for mobile and speed step processors, tray icon |
| mode, statistics, memory usage, and more.                                    |
|                                                                              |
| It comes integrated with a sophisticated processor detection toolkit which   |
| provides detailed CPU information, list of supported CPU features and other  |
| specifics.                                                                   |
|                                                                              |
| Hasher Pro                                                                   |
| ==========                                                                   |
|                                                                              |
| Hashing utility for verifying integrity of files using a wide range of       |
| supported algorithms: CRC32, MD2, MD4, MD5, SHA1, SHA256, SHA512, RipeMD128, |
| RipeMD160, ED2K.                                                             |
|                                                                              |
| All processed files are logged and ready for export to a number of different |
| verification file formats: SFV, MD5SUM, SHA1SUM. Multiple hash types can be  |
| generated simultaneously per file. Handy hash and file comparison functions, |
| such as holding SHIFT to compare to next file or CTRL to compare two files,  |
| will make this task a breeze.                                                |
|                                                                              |
| Hooker Pro                                                                   |
| ==========                                                                   |
|                                                                              |
| Hooker is a lightweight keyboard activity spy. It allows capturing of all    |
| keystrokes made by the user, including any clipboard changes. Currently      |
| active process name and window title can be logged and used for filtering    |
| the captured data. It is Unicode aware, so characters generated in any       |
| language are going to be recorded correctly, even combining keys such as     |
| accents.                                                                     |
|                                                                              |
| Advanced logging facility can periodically save all of the activity in a log |
| file, send via email or upload to an FTP server. The program is completely   |
| hidden during normal operation and is accessible only with a secret key      |
| combination (and a correct password in "Pro" version).                       |
|                                                                              |
| RandPass Pro                                                                 |
| ============                                                                 |
|                                                                              |
| Random password generator. A simple tool for generating random passwords     |
| using either random symbols or random words.                                 |
|                                                                              |
| User can easily select groups of characters used for passwords, including    |
| lower case letters, upper case letters, digits, specify custom character set |
| and formatting of the password, check for uniqueness, eliminate similar      |
| characters and more. Word list based password generation provides several    |
| common word lists, including Diceware and EFF, with an option of using a     |
| custom word list file.                                                       |
|                                                                              |
| Application also supports command line execution for unattended generation   |
| of passwords.                                                                |
|                                                                              |
| ReNamer Pro                                                                  |
| ===========                                                                  |
|                                                                              |
| ReNamer is a very powerful and flexible file renaming tool, which offers all |
| the standard renaming procedures, including prefixes, suffixes,              |
| replacements, case changes, as well as removing contents of brackets, adding |
| number sequences, changing file extensions, etc. For advanced users there is |
| support for Regular Expressions and a PascalScript rule, which lets users    |
| program their very own renaming rule.                                        |
|                                                                              |
| Program allows you to combine multiple renaming actions as a rule set,       |
| applying each action in a logical sequence, which can be saved, loaded, and  |
| managed within the program. In addition, it has an ability to rename         |
| folders, process regular expressions, Unicode capable, and supports variety  |
| of meta tags, such as: ID3v1, ID3v2, EXIF, OLE, AVI, MD5, CRC32, and SHA1.   |
|                                                                              |
| Resizer Pro                                                                  |
| ===========                                                                  |
|                                                                              |
| Batch image resizer. It has an easy to use drag-n-drop interface with        |
| variety of options, such as aspect ratio fit methods, target image formats,  |
| customizable output filename pattern and more.                               |
|                                                                              |
| Supported image formats: BMP, GIF, PNG, JPEG, TIFF.                          |
|                                                                              |
| Shutter Pro                                                                  |
| ===========                                                                  |
|                                                                              |
| Shutter is a multifunctional scheduling utility, which has a user friendly   |
| and easy-to-use interface and supports many different Events and Actions.    |
|                                                                              |
| Available events: Countdown, On Time, Winamp Stops, CPU Usage, Network       |
| Usage, Hard Disk Usage, User Inactive, Battery Low, Window, Process, Ping    |
| Stops, File Size Limit, Lid.                                                 |
|                                                                              |
| Available actions: Shutdown, Reboot, Log Off, Lock Workstation, Sleep,       |
| Hibernate, Turn Off Monitor, Screen Saver, Volume Control, Hang Up Modem,    |
| Alarm, Message, Play Sound, Run Program, Open File, Close Window, Kill       |
| Process.                                                                     |
|                                                                              |
| Desktop links can be created to execute any of the supported actions         |
| directly from desktop. Web Interface allows remote execution of actions and  |
| displays run-time information about the computer: Up Time, List of           |
| Processes, Screenshot of a Desktop, Program Execution, and more.             |
|                                                                              |
+-[ HOW TO USE ]---------------------------------------------------------------+
|                                                                              |
| 1. Select the target product from the list, complete the required license    |
|    info fields and click "Generate" button.                                  |
|                                                                              |
| 2. Use the generated reg. code to register the program.                      |
|                                                                              |
+-[ FOR EVALUATION PURPOSES ONLY ]---------------------------------------------+
|                                                                              |
| If you can afford it, please BUY IT. Support the developer to make a better  |
| product.                                                                     |
|                                                                              |
+-[ RELEASES/UPDATES ]---------------------------------------------------------+
|                                                                              |
| https://radixx11rce.blogspot.com                                             |
|                                                                              |
================================================================================
